

<?php $__env->startSection('content'); ?>
    <h2>Add Category</h2>

    <form action="<?php echo e(url('categories')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="">NAME</label>
            <input type="text" name="cat_name" id="" class="form-control">
        </div>
        <div class="mb-3">
            <input type="submit" value="SAVE" class="btn btn-primary">
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl-project11\resources\views/categories/create.blade.php ENDPATH**/ ?>